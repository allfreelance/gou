
$('.select-ege').selectric();
$('.select-institution').selectric();
$('.select-faculty').selectric();
$('.select-city').selectric();


// open division

const divisionBtn = document.querySelectorAll('.division__details');

for (let i = 0; i < divisionBtn.length; i++) {
  divisionBtn[i].addEventListener('click', function() {
    let parentDivision = this.closest('.division');
    let divisionWrapper = parentDivision.querySelector('.division__cards-wrapper');
    divisionWrapper.classList.toggle('open');
  })
}
