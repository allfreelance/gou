# newProject
> Used HTML, CSS/SASS, JS, Gulp, Git.
> Layout in compliance with BEM semantics and methodology. Green zone GooglePageSpeed.

#### Compiles and hot-reloads for development
> gulp

#### Compiles and minifies for production
> gulp build



