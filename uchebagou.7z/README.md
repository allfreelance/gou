#### Compiles and hot-reloads for development
> gulp

#### Compiles and minifies for production
> gulp build

